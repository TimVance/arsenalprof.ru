<?
$sSectionName="b2bshop_mail";
?>