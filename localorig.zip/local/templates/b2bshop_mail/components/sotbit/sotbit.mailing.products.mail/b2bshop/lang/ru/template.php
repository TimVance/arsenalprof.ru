<?
$MESS["CATALOG_BUY_PRODUCTS_MAIL_TITLE"] = "Вас также могут заинтересовать";
$MESS["CATALOG_BUY_PRODUCTS_MAIL_BASKET"] = "Купить";

$MESS["MAIL_NAME"] = "Наименование";
$MESS["MAIL_ARTICLE"] = "Артикул";
$MESS["MAIL_PRICE"] = "Стоимость";


?>