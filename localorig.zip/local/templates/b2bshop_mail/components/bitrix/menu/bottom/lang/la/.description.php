<?
$MESS["MENU_DOT_DEFAULT_NAME"] = "MenР вЂњРЎвЂќ vertical del defecto";
$MESS["MENU_DOT_DEFAULT_DESC"] = "MenР вЂњРЎвЂќ vertical del defecto";
?>