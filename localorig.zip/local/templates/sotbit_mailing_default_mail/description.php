<?
$arTemplate = array (
  'NAME' => GetMessage('TEMPLATE_NAME'),
  'DESCRIPTION' => GetMessage('TEMPLATE_DESCRIPTION'),
  'SORT' => '',
  'TYPE' => 'mail',
);
?>