<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS["SAP_BUY_MONEY"] = "Пополнить счет";
$MESS["SAP_FIXED_PAYMENT"] = "Фиксированный платёж";
$MESS["SAP_LINK_TITLE"] = "Занести на счет";
$MESS["SAP_INPUT_PLACEHOLDER"] = "Введите значение";
$MESS["SAP_ERROR_INPUT"] = "Введите значение больше нуля";
$MESS["SAP_BUTTON"] = "Купить";
$MESS["SAP_SUM"] = "Сумма";
$MESS["SAP_TYPE_PAYMENT_TITLE"] = "Метод оплаты";
$MESS["SAP_RUB"] = "руб.";
?>
