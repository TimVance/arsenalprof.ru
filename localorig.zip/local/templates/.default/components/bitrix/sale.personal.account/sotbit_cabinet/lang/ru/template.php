<?
$MESS["SPA_BILL_AT"] = "Состояние счета на";

