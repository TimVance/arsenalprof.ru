<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arParameters = Array(
	"PARAMETERS" => Array(
		"PATH_TO_BASKET" => array(
			"NAME" => GetMessage("GD_SOTBIT_CABINET_DELAYCART_PATH_TO_CART"),
			"TYPE" => "STRING",
			"DEFAULT" => "/personal/cart/?delay=1"
		)
	)
);
?>
