<?
$MESS ['GD_SOTBIT_CABINET_DELAYCART_PATH_TO_CART'] = "Путь к корзине";
?>