<?
$MESS ['GD_SOTBIT_CABINET_REVIEWS_NAME'] = "Мои отзывы";
$MESS ['GD_SOTBIT_CABINET_REVIEWS_DESC'] = "Выводит отзывы пользователя";
?>