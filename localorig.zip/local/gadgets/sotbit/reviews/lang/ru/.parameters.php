<?
$MESS["GD_SOTBIT_CABINET_REVIEWS_CNT"] = "Количество отображ. отзывов";
$MESS["GD_SOTBIT_CABINET_REVIEWS_TYPE"] = "Тип отображ. отзывов";
$MESS["GD_SOTBIT_CABINET_REVIEWS_ALL"] = "Все";
$MESS["GD_SOTBIT_CABINET_REVIEWS_MODERATED"] = "Опубликованные";
$MESS["GD_SOTBIT_CABINET_REVIEWS_NOT_MODERATED"] = "Не опубликованные";
$MESS["GD_SOTBIT_CABINET_REVIEWS_MAX_RATING"] = "Максимальный рейтинг";
$MESS["GD_SOTBIT_CABINET_REVIEWS_PATH_TO_REVIEWS"] = "Страница всех отзывов пользователя";