<?php
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

/**
 * Created by PhpStorm.
 * User: Sergey
 * Date: 11/1/2017
 * Time: 1:16 PM
 */
$MESS['SOTBIT_CABINET_REVIEWS_MODERATED'] = 'Опубликован';
$MESS['SOTBIT_CABINET_REVIEWS_NOT_MODERATED'] = 'Не опубликован';
$MESS['SOTBIT_CABINET_REVIEWS_ALL'] = 'Все отзывы';