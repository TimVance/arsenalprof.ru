<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_SUBSCRIBE_NAME'] = "Подписка";
$MESS ['GD_SOTBIT_CABINET_SUBSCRIBE_DESC'] = "Выводит информацию о подписках пользователя";
?>