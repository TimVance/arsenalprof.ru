<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arParameters = Array(
		"PARAMETERS"=> Array(
				"PATH_TO_SUBSCRIBES" => array(
						"NAME" => GetMessage("GD_SOTBIT_CABINET_PROFILE_PATH_TO_SUBSCRIBES"),
						"TYPE" => "STRING",
						"DEFAULT" => "/personal/subcribe/"
				)
		));
?>
