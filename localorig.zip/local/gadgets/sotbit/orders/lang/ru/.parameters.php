<?
$MESS ['GD_SOTBIT_CABINET_PATH_TO_ORDER'] = "Путь к странице заказов";
$MESS ['GD_SOTBIT_CABINET_PATH_TO_ORDER_DETAIL'] = "Путь к детальной странице заказа";
$MESS ['GD_SOTBIT_CABINET_ORDER_LIMIT'] = "Кол-во отображ. заказов";
$MESS ['GD_SOTBIT_CABINET_ORDER_STATUS'] = "Тип отображ. заказов";
$MESS ['GD_SOTBIT_CABINET_ORDER_STATUS_ALL'] = "Все";
$MESS ['GD_SOTBIT_CABINET_ORDER_LIMIT'] = "Кол-во отображ. заказов";
?>