<?
$MESS['GD_SOTBIT_CABINET_BLANK_EXCEL_OUT'] = 'Выгрузить в Excel';
$MESS['GD_SOTBIT_CABINET_BLANK_EXCEL_IN'] = 'Загрузить из Excel';
$MESS['GD_SOTBIT_CABINET_BLANK_CHOOSE_FILE'] = 'Выберите файл';
$MESS['GD_SOTBIT_CABINET_BLANK_SEND'] = 'Отправить';
$MESS['GD_SOTBIT_CABINET_BLANK_MOVE'] = 'или перетащите его сюда';

?>