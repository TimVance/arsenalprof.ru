<?
$MESS["GD_SOTBIT_CABINET_BUYERS_PATH_TO_BUYER_DETAIL"] = "Путь к странице организаций";
?>