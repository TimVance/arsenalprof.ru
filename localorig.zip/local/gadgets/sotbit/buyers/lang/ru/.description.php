<?
$MESS ['GD_SOTBIT_CABINET_BUYERS_NAME'] = "Организации";
$MESS ['GD_SOTBIT_CABINET_BUYERS_DESC'] = "Выводит информацию об организациях покупателей";
?>