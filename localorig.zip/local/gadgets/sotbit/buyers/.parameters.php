<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arParameters = Array(
		"PARAMETERS"=> Array(
				"PATH_TO_BUYER_DETAIL" => array(
						"NAME" => GetMessage("GD_SOTBIT_CABINET_BUYERS_PATH_TO_BUYER_DETAIL"),
						"TYPE" => "STRING",
						"DEFAULT" => "/personal/profile/buyer/?id=#ID#"
				)
		));
?>
