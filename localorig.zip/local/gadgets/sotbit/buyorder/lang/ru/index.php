<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS['GD_SOTBIT_CABINET_BUYORDER_BUY_ONLINE'] = 'Оплатить онлайн';
$MESS['GD_SOTBIT_CABINET_BUYORDER_PERSON_TYPE'] = 'Тип плательщика:';
$MESS['GD_SOTBIT_CABINET_BUYORDER_DOWNLOAD'] = 'Скачать квитанцию';
$MESS['GD_SOTBIT_CABINET_BUYORDER_DATE'] = 'Дата:';
$MESS['GD_SOTBIT_CABINET_BUYORDER_SUM'] = 'Сумма платежа:';
?>