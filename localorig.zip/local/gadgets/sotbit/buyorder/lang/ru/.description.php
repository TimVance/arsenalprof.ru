<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_BUYORDER_NAME'] = "Счет ждет оплаты";
$MESS ['GD_SOTBIT_CABINET_BUYORDER_DESC'] = "Выводит информацию о последнем неоплаченном заказе";
?>