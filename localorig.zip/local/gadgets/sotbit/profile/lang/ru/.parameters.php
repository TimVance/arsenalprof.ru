<?
$MESS["GD_SOTBIT_CABINET_PROFILE_PATH_TO_PROFILE"] = "Путь к странице профиля покупателя";
?>