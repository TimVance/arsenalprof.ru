<?
$MESS['GD_SOTBIT_CABINET_PHONE'] = 'Телефон';
$MESS['GD_SOTBIT_CABINET_EMAIL'] = 'E-mail';
$MESS['GD_SOTBIT_CABINET_CHANGE'] = 'Изменить данные';
?>