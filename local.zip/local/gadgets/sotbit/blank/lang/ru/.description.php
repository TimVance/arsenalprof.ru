<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_BLANK_NAME'] = "Бланк заказа";
$MESS ['GD_SOTBIT_CABINET_BLANK_DESC'] = "Дает возможность выгружать и загружать бланк заказа";
?>