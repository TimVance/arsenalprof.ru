<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS["GD_SOTBIT_CABINET_PATH_TO_BLANK"] = "Путь к бланку заказа";
$MESS["GD_SOTBIT_CABINET_INIT_JQUERY"] = "Подключить JQuery";
?>