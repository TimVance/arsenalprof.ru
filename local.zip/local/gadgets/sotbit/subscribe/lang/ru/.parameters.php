<?
$MESS["GD_SOTBIT_CABINET_PROFILE_PATH_TO_SUBSCRIBES"] = "Путь к странице управления рассылками";
?>