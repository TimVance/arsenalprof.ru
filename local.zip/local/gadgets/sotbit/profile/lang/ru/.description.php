<?
$MESS ['GD_SOTBIT_CABINET_PROFILE_NAME'] = "Персональные данные";
$MESS ['GD_SOTBIT_CABINET_PROFILE_DESC'] = "Выводит информацию о профиле пользователя";
?>