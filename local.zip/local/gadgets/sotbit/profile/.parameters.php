<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arParameters = Array(
		"PARAMETERS"=> Array(
				"PATH_TO_PROFILE" => array(
						"NAME" => GetMessage("GD_SOTBIT_CABINET_PROFILE_PATH_TO_PROFILE"),
						"TYPE" => "STRING",
						"DEFAULT" => "/personal/profile/"
				)
		));
?>
