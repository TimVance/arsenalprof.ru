<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_ACCOUNT_NAME'] = "Личный счет";
$MESS ['GD_SOTBIT_CABINET_ACCOUNT_DESC'] = "Выводит информацию о личном счете пользователя";
?>