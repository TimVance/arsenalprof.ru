<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_DELAY_BASKET_NAME'] = "Отложенные товары";
$MESS ['GD_SOTBIT_CABINET_DELAY_BASKET_DESC'] = "Выводит информацию об отложенных товарах в  корзине пользователя";
?>