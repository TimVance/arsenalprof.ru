<?
$MESS ['GD_SOTBIT_CABINET_ORDERS_NAME'] = "Состояние заказов";
$MESS ['GD_SOTBIT_CABINET_ORDERS_DESC'] = "Выводит информацию о заказах покупателя";
?>