<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arDescription = Array(
		"NAME"=>GetMessage("GD_SOTBIT_CABINET_ORDERS_NAME"),
		"DESCRIPTION"=>GetMessage("GD_SOTBIT_CABINET_ORDERS_DESC"),
		"ICON"=>"",
		"GROUP"=> Array("ID"=>"personal"),
		"NOPARAMS"=>"Y",
		"SU"=> true,
		"SG"=> true,
		"AI"=> true
	);
?>
