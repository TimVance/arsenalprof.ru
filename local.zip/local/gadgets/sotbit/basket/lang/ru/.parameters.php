<?
$MESS ['GD_SOTBIT_CABINET_CART_PATH_TO_CAR'] = "Путь к корзине";
?>