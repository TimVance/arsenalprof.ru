<?
$MESS ['GD_SOTBIT_CABINET_BASKET_NAME'] = "Моя корзина";
$MESS ['GD_SOTBIT_CABINET_BASKET_DESC'] = "Выводит информацию о корзине пользователя";
?>