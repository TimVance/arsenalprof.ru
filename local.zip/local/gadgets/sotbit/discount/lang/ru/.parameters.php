<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS["GD_SOTBIT_CABINET_DISCOUNT_ID_DISCOUNT"] = "Скидка";
$MESS["GD_SOTBIT_CABINET_DISCOUNT_PATH_TO_PAGE"] = "Путь к странице";
?>