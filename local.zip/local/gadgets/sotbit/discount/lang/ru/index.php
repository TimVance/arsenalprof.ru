<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS['GD_SOTBIT_CABINET_DISCOUNT_MORE'] = 'Подробнее';
?>