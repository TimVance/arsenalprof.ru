<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS ['GD_SOTBIT_CABINET_DISCOUNT_NAME'] = "Скидки";
$MESS ['GD_SOTBIT_CABINET_DISCOUNT_DESC'] = "Выводит информацию о текущей скидики";
?>