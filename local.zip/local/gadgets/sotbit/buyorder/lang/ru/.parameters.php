<?
/**
 * Copyright (c) 2017. Sergey Danilkin.
 */

$MESS["GD_SOTBIT_CABINET_BUYORDER_PATH_TO_ORDER_DETAIL"] = "Путь к детальной странице заказа";
$MESS["GD_SOTBIT_CABINET_BUYORDER_ORG_PROP"] = "Свойство названии организации";
$MESS["GD_SOTBIT_CABINET_BUYORDER_PATH_TO_PAY"] = "Путь к странице оплаты";
?>