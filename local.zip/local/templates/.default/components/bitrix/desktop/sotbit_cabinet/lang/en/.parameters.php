<?
$MESS["CMDESKTOP_PARAMS_GADGETS_FIXED"] = "Gadgets A User Cannot Delete Or Configure";
?>