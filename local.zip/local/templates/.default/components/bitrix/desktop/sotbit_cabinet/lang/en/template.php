<?
$MESS["CMDESKTOP_TDEF_ERR1"] = "Error while saving gadget position to server.";
$MESS["CMDESKTOP_TDEF_ERR2"] = "Error while adding gadget to server.";
$MESS["CMDESKTOP_TDEF_CONF"] = "Your Personal Dashboard settings will be applied by default for all new or non-authorized users. Continue?";
$MESS["CMDESKTOP_TDEF_CONF_USER"] = "Your desktop settings will be applied to all new user profiles by default. Do you want to continue?";
$MESS["CMDESKTOP_TDEF_CONF_GROUP"] = "Your desktop settings will be applied to all new workgroups by default. Do you want to continue?";
$MESS["CMDESKTOP_TDEF_ADD"] = "Add";
$MESS["CMDESKTOP_TDEF_SET"] = "Save as default settings";
$MESS["CMDESKTOP_TDEF_CLEAR"] = "Reset current settings";
$MESS["CMDESKTOP_TDEF_CANCEL"] = "Cancel";
$MESS["CMDESKTOP_TDEF_DELETE"] = "Delete";
$MESS["CMDESKTOP_TDEF_SETTINGS"] = "Settings";
$MESS["CMDESKTOP_TDEF_CLEAR_CONF"] = "Default parameters will be applied to your desktop. Continue?";
$MESS["CMDESKTOP_TDEF_HIDE"] = "Hide/Show";
?>