




$(document).ready(function () {

    //Switch - Page Catalog
    $('.catalog__switch-table').on('click', function () {
        $('.catalog__card_wrap').addClass('catalog__card_tab');
        $('.catalog__switch-list').removeClass('active');
        $(this).addClass('active');
    });

    $('.catalog__switch-list').on('click', function () {
        $('.catalog__card_wrap').removeClass('catalog__card_tab');
        $('.catalog__switch-table').removeClass('active');
        $(this).addClass('active');
    });




    //Sidebar
    $('.sidebar-title').on('click', function () {
        $(this).toggleClass('active').next().stop(false, false).slideToggle();
    });

    $('.show__more').on('click', function () {
        $(this).prev().stop(false, false).addClass('sidebar__wrap-show');
        $(this).hide();
    });

    $('.sidebar__open').on('click', function () {
        $('.sidebar__item').slideToggle(0);
        $('.sidebar__open').toggleClass('sidebar__open_margin');
    });


    //basket
    $('.header__basket').on('click', function () {
        $('.basket').addClass('basket_open');
    });

    $('.basket_close svg').on('click', function () {
        $('.basket').removeClass('basket_open');
    });

    $('.basket__wrap_top').on('click', function () {
        $(this).toggleClass('active').next().stop(false, false).slideToggle();
    });


    //News
    $(".news__slider").owlCarousel({
        loop: true,
        dots: true,
        nav: true,
        margin: 10,
        mouseDrag:false,
        touchDrag:true,
        // autoplay: true,
        // smartSpeed: 1000,
        // autoplayTimeout: 2000,
        navClass: ['owl-prev', 'owl-next'],
        navText: false,
        responsive: {
            0: {
                items: 1,
                mouseDrag:false,
                touchDrag:true
            },
            1024: {
                items: 1,

            }
        }
    });

    //Home Product
    $(".products__wrap").owlCarousel({
        loop: false,
        dots: true,
        nav: true,
        margin: 25,
        mouseDrag:false,
        touchDrag:true,
        // autoplay: true,
        // smartSpeed: 1000,
        // autoplayTimeout: 2000,
        navClass: ['owl-prev', 'owl-next'],
        navText: false,
        responsive: {
            0: {
                items: 1,
                mouseDrag:false,
                touchDrag:true
            },
            540: {
                items: 2,
                margin: 15,
            },
            767: {
                items: 3,
                margin: 15,
            },
            992: {
                items: 4,
                margin: 15,
            },
            1270: {
                items: 5,
                margin: 15,
            },
            16000: {
                items: 5,

            }
        }
    });

    //Card Fotorama
    $('.fotorama').fotorama({
        nav: 'thumbs',
        thumbwidth: 50,
        thumbheight: 50,
        thumbmargin: 5,
        arrows: false,
        thumbborderwidth: 2,
        shadow: false,
        spinner: {
            lines: 23,
            color: 'rgba(0, 0, 0, .75)'
        },
    });

    $('.goods__gallery').fotorama({
        nav: 'thumbs',
        thumbwidth: 50,
        thumbheight: 50,
        thumbmargin: 15,
        arrows: false,
        shadow: false,
        spinner: {
            lines: 23,
            color: 'rgba(0, 0, 0, .75)'
        },
    });


    //Tabs BEGIN
    $(".tab_item").not(":first").hide();
    $(".tabs-wrap .tab").click(function() {
        $(".tabs-wrap .tab").removeClass("active").eq($(this).index()).addClass("active");
        $(".tab_item").hide().eq($(this).index()).fadeIn()
    }).eq(0).addClass("active");


    $('input[type="range"]').on("input change", function(e){
        e.preventDefault();
        var slideno = $(this).val();
        $('.slider-nav').slick('slickGoTo', slideno-7 );
    });

    $('#hamburger').on('click', function(){
        $("#menu").mmenu({
            "extensions": [
                "pagedim-black",
                "theme-dark"
            ]
        });
    });


    // Slider Page Home
    var $frame  = $('#basic');
    var $slidee = $frame.children('ul').eq(0);
    var $wrap   = $frame.parent();

    $frame.sly({
        horizontal: 1,
        itemNav: 'basic',
        smart: 1,
        activateOn: 'click',
        mouseDragging: 1,
        touchDragging: 1,
        releaseSwing: 1,
        // startAt: 3,
        scrollBar: $wrap.find('.scrollbar'),
        scrollBy: 0,
        activatePageOn: 'click',
        speed: 300,
        elasticBounds: 1,
        dragHandle: 1,
        dynamicHandle: 1,
        clickBar: 1,
        // Buttons
        prevPage: $wrap.find('.js-prev-page'),
        nextPage: $wrap.find('.js-next-page'),


    });



});

