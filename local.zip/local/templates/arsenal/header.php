<?php
use Bitrix\Main\Page\Asset;
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)    die();
$asset = Asset::getInstance();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?$APPLICATION->ShowTitle();?></title>
    <? $APPLICATION->ShowHead(); ?>
    <? $asset->addCss(SITE_TEMPLATE_PATH."/css/style.css"); ?>
    <? CJSCore::Init(array("jquery")); ?>
</head>
<body>

    <?$APPLICATION->ShowPanel();?>

    <div class="main">

        <div class="content">

            <header class="header">

                <div class="header__top">
                    <div class="container">
                        <div class="header__top_wrap">
                            <a id="hamburger" href="#menu">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                            <div class="header__top_item">
                                <div class="city">
                                    <svg>
                                        <use xlink:href="#location"/>
                                    </svg>
                                    <span class="city-title">Ваш город: <span>Красноярск</span></span>
                                </div>
                                <div class="header__top_profile">
                                    <div class="btn__profile btn__registration">
                                        <svg>
                                            <use xlink:href="#locked"/>
                                        </svg>
                                        <span>Регистрация</span>
                                    </div>
                                    <div class="btn__profile btn__open">
                                        <span>Войти</span>
                                    </div>
                                    <div class="btn__profile btn__cabinet">
                                        <svg>
                                            <use xlink:href="#user"/>
                                        </svg>
                                        <span>Личный кабинет</span>
                                    </div>
                                </div>
                            </div>
                            <div class="header__top_item header__top_right">
                                <a href="#" class="header__favorites">
                                    <svg>
                                        <use xlink:href="#heart"/>
                                    </svg>
                                </a>
                                <div class="header__statistic">
                                    <svg>
                                        <use xlink:href="#statistic"/>
                                    </svg>
                                </div>
                                <a href="#" class="header__basket">
                                    <svg>
                                        <use xlink:href="#basket"/>
                                    </svg>
                                    <div class="header__basket-quantity">12</div>
                                    <div class="header__basket-price">37 419 ₽</div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container">

                    <div class="header__wrap">
                        <div class="header__wrap_info">
                            <div class="header__wrap_info-item header__wrap_info-top">
                                <div class="header__wrap_info-item_left">
                                    <a href="/" class="logo">
                                        <svg>
                                            <use xlink:href="#logo"/>
                                        </svg>
                                    </a>
                                    <span class="header-subtitle">
                                            Заряжаем инструментом
                                        </span>
                                </div>
                                <form action="#" class="header__search">
                                    <input type="search" placeholder="Поиск по товарам и категориям">
                                    <button class="submit">Поиск</button>
                                </form>
                            </div>
                            <div class="header__wrap_info-item">
                                <ul class="header__menu">
                                    <li><a href="#">Бренды</a></li>
                                    <li><a href="#">Акции</a></li>
                                    <li><a href="#">Партнерам</a></li>
                                    <li><a href="#">Новости</a></li>
                                    <li><a href="#">Новинки</a></li>
                                    <li><a href="#">Сервис</a></li>
                                    <li><a href="#">Контакты</a></li>
                                </ul>
                                <div class="search__brands">
                                    <span class="search__brands-logo">AY</span>
                                    <span class="search__brands-title">Поиск по брендам</span>
                                </div>
                            </div>
                        </div>
                        <div class="header__wrap_phone">
                            <span class="header__phone-title">Бесплатный звонок</span>
                            <div class="header__phone-number">
                                <svg>
                                    <use xlink:href="#phone"/>
                                </svg>
                                <span>8 800 250 57 14</span>
                            </div>
                            <span class="header__order-call">Заказать бесплатный звонок</span>
                        </div>
                    </div>

                </div>

            </header>


            <section class="menu__section">
                <div class="container">

                    <ul class="menu">
                        <li>
                            <a href="catalog.html">Генераторы и мотопомпы</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Насосное оборудование</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Тепловые пушки, котлы, пеи и камины</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Садово техника</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Строительное оборудование и станки</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Компрессоры и пневмоинструмент</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Инструмент сетевой</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Бензоинструмент</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Аккумуляторное оборудование</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                        <li>
                            <a href="#">Зарядные устройства и стабилизаторы</a>
                            <div class="submenu">
                                <div class="submenu__info">
                                    <h2>Станки</h2>
                                    <div class="submenu__catalog">
                                        <a href="#" class="submenu__catalog_item">Новинки</a>
                                        <a href="#" class="submenu__catalog_item">Хиты продаж</a>
                                        <a href="#" class="submenu__catalog_item">Скидки</a>
                                    </div>
                                    <ul>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Насосы <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>

                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>

                                        <li><a href="#">Пушки оборудование <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                        <li><a href="#">Помпы <span>(21)</span></a></li>
                                        <li><a href="#">Бензоинструмент <span>(21)</span></a></li>
                                    </ul>
                                </div>
                                <div class="submenu__banner">
                                    <img src="<?php echo SITE_TEMPLATE_PATH ?>/images/Slider.png" alt="">
                                </div>

                            </div>
                        </li>
                    </ul>

                </div>
            </section>

            <section class="page__section">
                <div class="container">
                    <?$APPLICATION->IncludeComponent("bitrix:breadcrumb", "breadcrumb", array(
                        "START_FROM" => 1,
                        "PATH" => "",
                        "SITE_ID" => SITE_ID
                    ));?>
                    <h1 class="page-title"><?$APPLICATION->ShowTitle(false);?></h1>