<?
$arTemplate = array (
  'NAME' => 'Арсенал',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>