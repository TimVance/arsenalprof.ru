<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Персональные рекомендации";
$MESS["CATALOG_POPULAR_IN_SECTION"] = "Популярные в разделе";
$MESS["CATALOG_RECOMMENDED_BY_LINK"] = "С этим товаром рекомендуем";
$MESS["CATALOG_VIEWED"] = "Просматривали";