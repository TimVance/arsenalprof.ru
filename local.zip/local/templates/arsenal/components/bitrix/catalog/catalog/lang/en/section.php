<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Personal recommendations";
?>