<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Personal recommendations";
$MESS["CATALOG_POPULAR_IN_SECTION"] = "Popular Items";
$MESS["CATALOG_VIEWED"] = "Viewed Items";
$MESS["CATALOG_RECOMMENDED_BY_LINK"] = "Recommended Products";
?>