<?
$MESS ['T_IBLOCK_VOTE_RESULTS'] = "(Голосов: #VOTES#, Рейтинг: #RATING#)";
$MESS ['T_IBLOCK_VOTE_NO_RESULTS'] = "(Нет голосов)";
?>