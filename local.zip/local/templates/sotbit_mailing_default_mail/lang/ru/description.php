<?
$MESS["TEMPLATE_NAME"] = "Шаблон модуля sotbit.mailing";
$MESS["TEMPLATE_DESCRIPTION"] = "Стандартный шаблон модуля маркетинговых рассылок.";
?>