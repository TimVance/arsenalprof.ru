<?
$MESS["TEMPLATE_FOOTER_CONTACTS"] = "Контактные данные";
$MESS["TEMPLATE_FOOTER_COORDINATES"] = "Наши координаты:";
$MESS["TEMPLATE_FOOTER_ADDRESS"] = "429950 Россия, Ленинградская область г.Санкт-Петербург, ул.Промышленная, д.91";
$MESS["TEMPLATE_FOOTER_HOW_TO_CONTACT_US"] = "Как с нами связаться:";
$MESS["TEMPLATE_FOOTER_PHONE"] = "Тел.: (800) 111-22-33";
$MESS["TEMPLATE_FOOTER_EMAIL"] = "e-mail: info@#SITE_URL#";
$MESS["TEMPLATE_FOOTER_UNSUBSCRIBE"] = "Отписаться от рассылки";
?>