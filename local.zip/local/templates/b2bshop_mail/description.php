<?
$arTemplate = array (
  'NAME' => 'Почтовый шаблон B2BShop',
  'DESCRIPTION' => 'Почтовый шаблон B2BShop',
  'SORT' => 100,
  'TYPE' => 'mail',
);
?>