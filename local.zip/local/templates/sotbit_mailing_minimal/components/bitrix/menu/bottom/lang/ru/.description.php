<?
$MESS ['MENU_DOT_DEFAULT_NAME'] = "Нижнее меню";
$MESS ['MENU_DOT_DEFAULT_DESC'] = "Нижнее меню";
?>