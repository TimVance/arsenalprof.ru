<?
$MESS ['MENU_DOT_DEFAULT_NAME'] = "Верхнее меню";
$MESS ['MENU_DOT_DEFAULT_DESC'] = "Верхнее меню";
?>