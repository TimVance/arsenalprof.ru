<?
$MESS["TEMPLATE_NAME"] = "Почтовый шаблон модуля sotbit.mailing";
$MESS["TEMPLATE_DESCRIPTION"] = "Почтовый шаблон модуля sotbit.mailing";
?>